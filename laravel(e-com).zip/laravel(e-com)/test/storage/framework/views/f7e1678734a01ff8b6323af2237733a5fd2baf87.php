<!DOCTYPE html>
<html>
<head>
    <title>Update Profile</title>
</head>
<body>
    <form method="post">
    Name: <input type="text" name="name" value="<?php echo e($user['name']); ?>">
	Email: <input type="text" name="email" value="<?php echo e($user['email']); ?>"> 
	Password: <input type="text" name="password" value="<?php echo e($user['password']); ?>">
	<input type="hidden" name="uid" value="<?php echo e($user['id']); ?>">
	<input type="submit" value="update">
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\stk\test\resources\views/updateprofile/index.blade.php ENDPATH**/ ?>