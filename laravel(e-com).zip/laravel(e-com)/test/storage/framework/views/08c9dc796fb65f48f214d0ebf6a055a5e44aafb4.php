<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
</head>
<body>
    <form method="post">
	Name: <input type="text" name="name">
	Email: <input type="text" name="email">
	Password: <input type="password" name="password">
	<input type="submit" name="submit" value="Registration">
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\stk\test\resources\views/registration/index.blade.php ENDPATH**/ ?>