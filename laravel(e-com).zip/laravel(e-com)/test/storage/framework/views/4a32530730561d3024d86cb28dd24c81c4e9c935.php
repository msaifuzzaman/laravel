<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
</head>
<body>
    <table>
	    <tr>
		    <td>Product Name</td>
			<td>Price</td>
		</tr>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
			    <td><?php echo e($p['name']); ?></td>
				<td><?php echo e($p['price']); ?></td>
				<td><a href="<?php echo e(route('buy.index',$p['id'])); ?>">Buy</a></td>
			</tr>
			
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\stk\test\resources\views/productdetails/index.blade.php ENDPATH**/ ?>