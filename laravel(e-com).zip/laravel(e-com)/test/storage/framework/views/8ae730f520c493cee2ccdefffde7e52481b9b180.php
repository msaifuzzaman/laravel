<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    welcome home!<br><br>
	
	
	<a href="<?php echo e(route('login.index')); ?>">Login</a>
	<a href="<?php echo e(route('registration.index')); ?>">Registration</a>
	<a href="<?php echo e(route('updateprofile.index')); ?>">Update Profile</a>
	<a href="<?php echo e(route('productdetails.index')); ?>">Show Products</a>
	<a href="">Logout</a>
</body>
</html><?php /**PATH C:\xampp\htdocs\stk\test\resources\views/home/index.blade.php ENDPATH**/ ?>