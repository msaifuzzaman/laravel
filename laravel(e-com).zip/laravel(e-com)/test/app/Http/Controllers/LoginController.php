<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class LoginController extends Controller
{
    public function index(){
		return view('login.index');
	}
	public function verify(Request $req){
		$user = DB::table('users')->where('email',$req->email)
		->where('password',$req->password)
		->first();
		if($user){
			$req->session()->put('email',$user->email);
			$req->session()->put('id',$user->id);
			return redirect()->route('home.index');
		}
		else{
			return redirect()->route('login.index');
		}
	}
}
