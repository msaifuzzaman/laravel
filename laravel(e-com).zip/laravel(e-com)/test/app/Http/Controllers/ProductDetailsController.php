<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Products;

class ProductDetailsController extends Controller
{
    public function index(){
		$p = Products::all();
		return view('productdetails.index')->with('products',$p);
	}
}
