<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Users;

class RegistrationController extends Controller
{
    public function index(){
		return view('registration.index');
	}
	public function verify(Request $req){
		$u = new Users;
		$u->name = $req->name;
		$u->email = $req->email;
		$u->password = $req->password;
		$u->save();
		return redirect()->route('login.index');
	}
}
