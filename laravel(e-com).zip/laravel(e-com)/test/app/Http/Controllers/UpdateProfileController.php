<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Users;

class UpdateProfileController extends Controller
{
    public function index(){
		$u = Users::find(session('id'));
		return view('updateprofile.index')->with('user',$u);
	}
	public function update(Request $req){
		$u = Users::find($req->uid);
		$u->name = $req->name;
		$u->email = $req->email;
		$u->password = $req->password;
		$u->save();
		return redirect()->route('home.index');
	}
}
