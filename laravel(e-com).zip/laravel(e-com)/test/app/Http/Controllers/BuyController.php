<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Products;

class BuyController extends Controller
{
    public function index($id){
		$p = Products::destroy($id);
		return redirect()->route('productdetails.index');
	}
}
