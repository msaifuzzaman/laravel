<!DOCTYPE html>
<html>
<head>
    <title>Update Profile</title>
</head>
<body>
<style>

body
{
	background-color:Gray;
	text-align:center;
}

#sdmsg,#sdmsg1{color:red;}
</style>
    <form method="post">
    Name: <input type="text" name="name" value="{{$user['name']}}">
	Email: <input type="text" name="email" value="{{$user['email']}}"> 
	Password: <input type="text" name="password" value="{{$user['password']}}">
	<input type="hidden" name="uid" value="{{$user['id']}}">
	<input type="submit" value="update">
	</form>
</body>
</html>