<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    welcome home!<br><br>
	
	
	<a href="{{route('login.index')}}">Login</a>
	<a href="{{route('registration.index')}}">Registration</a>
	<a href="{{route('updateprofile.index')}}">Update Profile</a>
	<a href="{{route('productdetails.index')}}">Show Products</a>
	<a href="">Logout</a>
</body>
</html>