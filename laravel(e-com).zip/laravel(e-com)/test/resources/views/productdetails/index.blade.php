<!DOCTYPE html>
<html>
<head>
    <title>Product Details</title>
</head>
<body>
    <table>
	    <tr>
		    <td>Product Name</td>
			<td>Price</td>
		</tr>
		@foreach($products as $p)
		    <tr>
			    <td>{{$p['name']}}</td>
				<td>{{$p['price']}}</td>
				<td><a href="{{route('buy.index',$p['id'])}}">Buy</a></td>
			</tr>
			
			
		@endforeach
	</table>
</body>
</html>