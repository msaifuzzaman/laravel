<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <form method="post">
	Email: <input type="text" name="email">
	Password: <input type="password" name="password">
	<input type="submit" name="submit" value="Login">
	</form>
</body>
</html>